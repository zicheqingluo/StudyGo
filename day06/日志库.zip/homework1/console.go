package homework1

import (
	"os"
	"strings"
	"fmt"
	"time"
)

//定义结构体
type consoleLogger struct {
	level	logLevel	
	isFile	bool
	filePath	string
	fileName	string
	fileObj		*os.File
}
//构造函数
func NewConsoleLogger(level string) *consoleLogger{
	level = strings.ToUpper(level)
	Level,err := parseLogLevel(level)
	if err != nil {
		fmt.Printf("解析级别出现错误，err",err)
	}
	return &consoleLogger{
		level:Level,
		isFile:false,
	}
}

//日志开关，确定当前日志级别是否可以打印，返回true则可以打印
func (c consoleLogger)isTrue(cLevel logLevel) bool {
	return cLevel >= c.level
}

//定义日志格式，打印日志到文件或屏幕
func (c *consoleLogger)messageFormat(lv logLevel,message string){
		now := time.Now()
		funcName,fileName,lineNo := getInfo(3)
		//定义日志格式
		msg := fmt.Sprintf("[%s] [%v] [%s:%s:%d] %s\n",now.Format("2006-01-02 15:04:05"),getLogString(lv),fileName, funcName, lineNo,message)
	if c.isTrue(lv) {
		fmt.Printf(msg) //输出至屏幕
		if c.isFile{
			if c.checkTime() {
				
				c.MoveFile()
			    }
			}

			fmt.Fprintf(c.fileObj,msg)

		

}
}

func (c consoleLogger)Debug(message string){
	c.messageFormat(DEBUG,message)
}

func (c consoleLogger)Info(message string){
	c.messageFormat(INFO,message)
}